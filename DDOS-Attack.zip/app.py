from flask import Flask, render_template, request, redirect, url_for, session, flash
import joblib
import pandas as pd
import g4f
import json
import os
from flask_mail import Mail, Message

app = Flask(__name__)
app.secret_key = 'your_secret_key'  # Replace with your actual secret key

# Configure Flask-Mail
app.config['MAIL_SERVER'] = 'smtp.gmail.com'  # Change for other providers
app.config['MAIL_PORT'] = 587
app.config['MAIL_USE_TLS'] = True
app.config['MAIL_USERNAME'] = 'daminmain@gmail.com'  # Replace with your email
app.config['MAIL_PASSWORD'] = 'kpqtxqskedcykwjz'  # Replace with your app password
app.config['MAIL_DEFAULT_SENDER'] = 'your_email@gmail.com'

mail = Mail(app)

# Path to the JSON database
USER_DB_PATH = 'users.json'

def load_model(model_path):
    """Load saved pipeline and label encoder"""
    artifacts = joblib.load(model_path)
    return artifacts['pipeline'], artifacts['label_encoder']

def predict_new_data(input_data, model_path='xgboost_model.pkl'):
    """Make predictions on new data"""
    pipeline, label_encoder = load_model(model_path)

    new_data = pd.DataFrame([input_data])
    new_data['timestamp'] = pd.to_datetime(new_data['timestamp'])
    new_data['hour'] = new_data['timestamp'].dt.hour
    new_data['minute'] = new_data['timestamp'].dt.minute
    new_data['day_of_week'] = new_data['timestamp'].dt.dayofweek
    processed_data = new_data.drop(['timestamp', 'dest_ip'], axis=1)

    prediction = pipeline.predict(processed_data)

    return {
        'input_features': input_data,
        'predicted_attack': label_encoder.inverse_transform(prediction)[0]
    }

def generate_prediction_description(prediction_result):
    """Generate a description based on the prediction result."""
    system_prompt = "You are an AI that provides detailed explanations about network security predictions."

    attack_type = prediction_result['predicted_attack']
    user_input = f"The predicted attack type is '{attack_type}'. Please provide a detailed explanation of this attack type."

    try:
        response = g4f.ChatCompletion.create(
            model="gpt-4o",
            messages=[{"role": "system", "content": system_prompt},
                      {"role": "user", "content": user_input}],
            temperature=0.6,
            top_p=0.9
        )
        return response.strip() if response else "Error: Unable to generate description."
    except Exception as e:
        return f"Error: {e}"

def load_users():
    """Load users from the JSON database"""
    if os.path.exists(USER_DB_PATH):
        with open(USER_DB_PATH, 'r') as file:
            return json.load(file)
    return {}

def save_users(users):
    """Save users to the JSON database"""
    with open(USER_DB_PATH, 'w') as file:
        json.dump(users, file)

def send_email(to_email, subject, body):
    """Send email using Flask-Mail"""
    try:
        msg = Message(subject, recipients=[to_email])
        msg.body = body
        mail.send(msg)
        return True
    except Exception as e:
        print(f"Error sending email: {e}")
        return False

@app.route('/landing')
def landing():
    return render_template('landing.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        email = request.form['email']

        users = load_users()
        if username in users:
            flash('Username already exists', 'danger')
        else:
            users[username] = {'password': password, 'email': email}
            save_users(users)

            # Send confirmation email
            subject = "Registration Successful"
            body = f"Hello {username},\n\nYour registration was successful. You can now log in.\n\nThank you!"
            send_email(email, subject, body)

            flash('Registration successful. Check your email.', 'success')
            return redirect(url_for('login'))

    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        users = load_users()
        if username in users and users[username]['password'] == password:
            session['username'] = username
            flash('Login successful', 'success')
            return redirect(url_for('index'))
        else:
            flash('Invalid username or password', 'danger')

    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('username', None)
    flash('Logout successful', 'success')
    return redirect(url_for('landing'))

@app.route('/', methods=['GET', 'POST'])
def index():
    if 'username' not in session:
        return redirect(url_for('landing'))

    users = load_users()
    user_email = users.get(session['username'], {}).get('email', '')

    if request.method == 'POST':
        sample_input = {
            'timestamp': request.form['timestamp'],
            'source_ip': request.form['source_ip'],
            'dest_ip': request.form['dest_ip'],
            'source_port': int(request.form['source_port']),
            'dest_port': int(request.form['dest_port']),
            'protocol': request.form['protocol'],
            'packet_count': int(request.form['packet_count']),
            'byte_count': int(request.form['byte_count']),
            'duration': float(request.form['duration'])
        }

        prediction_result = predict_new_data(sample_input)
        description = generate_prediction_description(prediction_result)

        # Send prediction result via email
        subject = "Network Attack Prediction Result"
        body = f"Hello,\n\nYour recent network traffic analysis predicted the attack type: {prediction_result['predicted_attack']}.\n\nDetails:\n{description}\n\nStay safe!"
        send_email(user_email, subject, body)

        return render_template('result.html',
                               input_features=prediction_result['input_features'],
                               predicted_attack=prediction_result['predicted_attack'],
                               description=description)

    return render_template('index.html')

if __name__ == "__main__":
    app.run(debug=True)
